# HypersistentSketch

* Hypersistent Sketch: Enhanced Persistence Estimation via Fast Item Separation (IEEE ICDE, 2025)
* Authors: Lu Cao, Qilong Shi, Weiqiang Xiao, Nianfu Wang, Wenjun Li*, Zhijun Li, Weizhe Zhang*, and Mingwei Xu
* Corresponding e-mail: wenjunli@pku.org.cn
* Paper Website: https://www.wenjunli.com/HypersistentSketch
