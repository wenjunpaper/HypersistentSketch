#ifndef PSKETCH_H
#define PSKETCH_H

#include "Abstract.h"
#include <random>
#include <algorithm> // For std::max
#include <limits>    // For std::numeric_limits

template<typename DATA_TYPE, typename COUNT_TYPE>
class PSketch : public Abstract<DATA_TYPE, COUNT_TYPE> {
private:
    struct Bucket {
        DATA_TYPE key;         // item key
        COUNT_TYPE p;          // persistence counter
        COUNT_TYPE h;          // hotness counter
        bool flag;             // On/Off flag

        Bucket() : key(0), p(0), h(0), flag(true) {}
    };

    int depth;          // r in pseudocode
    int width;          // w in pseudocode
    int eta;            // η parameter for replacement probability
    Bucket** buckets;
    std::random_device rd;
    std::mt19937 gen;
    std::uniform_real_distribution<> dis;

public:
    PSketch(int _depth, int _width, int _window_size /* not used */, int _eta = 18)
            : depth(_depth), width(_width), eta(_eta),
              gen(rd()), dis(0.0, 1.0) {

        buckets = new Bucket*[depth];
        for(int i = 0; i < depth; i++) {
            buckets[i] = new Bucket[width];
        }
    }

    ~PSketch() {
        for(int i = 0; i < depth; i++) {
            delete[] buckets[i];
        }
        delete[] buckets;
    }

    void Insert(const DATA_TYPE item, const COUNT_TYPE window) override {

        COUNT_TYPE min_val = std::numeric_limits<COUNT_TYPE>::max();
        int min_row = -1, min_col = -1;

        // Stage I: Finding an available bucket
        for(int i = 0; i < depth; i++) {
            int index = this->hash(item, i) % width;

            // Case 1: Empty bucket found
            if(buckets[i][index].p == 0) {
                buckets[i][index].key = item;
                buckets[i][index].p = 1;
                buckets[i][index].h = 1;
                buckets[i][index].flag = false; // Set to Off
                return;
            }

            // Case 2: Found the same item, and it's the first time in this window
            if(buckets[i][index].key == item) {
                if (buckets[i][index].flag) { // flag is On
                    buckets[i][index].p += 1;
                    buckets[i][index].h += 1;
                    buckets[i][index].flag = false; // Set to Off
                }
                // If flag is already Off, do nothing (as per paper)
                return;
            }

            // Case 3: Hash collision, track the bucket with the minimum (p+h) for potential replacement
            COUNT_TYPE sum = buckets[i][index].p + buckets[i][index].h;
            if(sum < min_val) {
                min_val = sum;
                min_row = i;
                min_col = index;
            }
        }

        // If we reach here, it means the item was not found and all hashed buckets are occupied.
        // Proceed to Stage II.

        // Stage II: Probability-based replacement
        if (min_row == -1) { // Should not happen if depth > 0
            return;
        }

        // If the flag of the victim bucket is Off, the new item gives up the replacement.
        if(buckets[min_row][min_col].flag == false) {
            return;
        }

        double prob = 1.0 / (static_cast<double>(eta) * (buckets[min_row][min_col].p + buckets[min_row][min_col].h) + 1.0);

        if(dis(gen) < prob) {
            // Replacement is successful
            buckets[min_row][min_col].key = item;
            // The paper increments the existing counter.
            buckets[min_row][min_col].p += 1;
            buckets[min_row][min_col].h += 1;
            buckets[min_row][min_col].flag = false;
        }
    }

    COUNT_TYPE Query(const DATA_TYPE item) override {
        // An item should only be in one bucket. Find it and return its persistence.
        for(int i = 0; i < depth; i++) {
            int index = this->hash(item, i) % width;
            if(buckets[i][index].key == item) {
                return buckets[i][index].p;
            }

        }
        // If not found, its persistence is 0.
        return 0;
    }

    void NewWindow(const COUNT_TYPE window) override {
        for(int i = 0; i < depth; i++) {
            for(int j = 0; j < width; j++) {
                if (buckets[i][j].p == 0) continue; // Skip empty buckets

                if(buckets[i][j].flag) { // If flag is On (not arrived in last window)
                    buckets[i][j].h = (buckets[i][j].h > 0) ? buckets[i][j].h - 1 : 0;
                } else { // If flag is Off (arrived in last window)
                    buckets[i][j].flag = true; // Reset to On for the new window
                }
            }
        }
    }

    std::string getName() override {
        return "PS";
    }

    void reset() override {
        for(int i = 0; i < depth; i++) {
            for(int j = 0; j < width; j++) {
                buckets[i][j].key = 0;
                buckets[i][j].p = 0;
                buckets[i][j].h = 0;
                buckets[i][j].flag = true;
            }
        }
    }
};

#endif //PSKETCH_H