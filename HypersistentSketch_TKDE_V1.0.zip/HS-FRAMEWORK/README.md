# Hypersistent Sketch

* Filtering and Accelerating: A Unified Framework for High-Performance Persistence Estimation

# Introduction

* The source codes of Hypersistent Sketch and other related algorithms.

# How to run

Suppose you've already cloned the repository.

You just need:

```
$ cmake .
$ make
$ ./bench (-d dataset -m memory -w window's size)
```

**optional** arguments:

- -d: set the path of dataset to run, default dataset is CAIDA "./data/caida.dat"
- -m: set the memory size (KB), default memory is 50KB
- -w: set the size of window, default **w** is 3000